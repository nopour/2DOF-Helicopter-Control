A=[      0         0    1.0000         0
         0         0         0    1.0000
         0         0   -9.2751         0
         0         0         0   -3.4955];

B=[      0         0
         0         0
    2.3667    0.0790
    0.2410    0.7913];

C=[  1     0     0     0
     0     1     0     0];

 D=[  0     0
     0     0];
%% ITAE Configuration %%%%%%%%%%%%%%%%%%%

n=4 ;   % n is order of the TF.denominator 
w_n = 8;
% % Desired Characteristic Eq in order 4
Delta_D = A^4 + 2.1*w_n*(A^3) + 3.4*(w_n^2)*(A^2)...
    + 2.7*(w_n^3)*A + (w_n^4)*eye(4);

syms s
poles_1=vpa(solve(s^4 + 2.1*w_n*(s^3)...
    + 3.4*(w_n^2)*(s^2)+ 2.7*(w_n^3)*(s) + (w_n^4)));
poles=double(poles_1);

K_ITAE = place(A,B,poles)  % K obtained from ITAE criteria
A_new = A-B*K_ITAE ;
sys_newITAE = ss(A_new,B,C,D);
%% BESSEL Configuration %%%%%%%%%%%%%%%%%%%
syms s
S_desired = s^4 + 10*s^3 + 45*s^2 + 105*s + 105;

num=105;
den=(s/w_n)^4 + 10*(s/w_n)^3 + 45*(s/w_n)^2 + 105*(s/w_n) + 105 ;

poles = double(vpasolve(den==0))
K_Bessel = place(A,B,poles)  % K obtained from Bessel criteria
A_new = A-B*K_Bessel ;
sys_newBessel = ss(A_new,B,C,D)

syms s
%% Butterworth Configuration %%%%%%%%%%%%%%%%%%%
Delta_c=zeros(n,n);
j=1;
poles=zeros(2*n,1);
left_poles=zeros(n,1);

% The roots are achived by:
poles=vpa(solve((s/w_n)^(2*n)==(-1)^(n+1)));

% consider poles in the left side of the Imaginary axes

for i=1:8
if real(poles(i,1))<0 ;
left_poles(j)=poles(i,1);
j=j+1;
end
end

% Characteristic Equation
N=poly(left_poles);
poles_2=left_poles;
for m=1:n+1
if m~=n+1
Delta_c= Delta_c + N(m)*A^(n-m+1);
else
Delta_c=Delta_c + N(m)*eye(n);
end
end


K_Butter = place(A,B,poles_2)  % K obtained from Butterworth criteria
A_new = A-B*K_Butter ;
sys_newButterworth = ss(A_new,B,C,D)
%%

figure
initial(sys_newITAE,[1 0 1 0])
hold on
initial(sys_newBessel,[1 0 1 0])
hold on
initial(sys_newButterworth,[1 0 1 0])
legend('ITAE','Bessel','Butterworth','Interpreter','latex')
% Control Effort
[y1,t1,x1]=initial(sys_newITAE,[1 0 1 0]);
CF1=-y1*KK;
[y2,t2,x2]=initial(sys_newBessel,[1 0 1 0]);
CF2=-y2*KK2;
[y3,t3,x3]=initial(sys_newButterworth,[1 0 1 0]);
CF3=-y3*KK3;
figure
plot(t1,CF1(:,1),'-','LineWidth',2)
hold on
plot(t2,CF2(:,1),'--','LineWidth',2)
hold on
plot(t3,CF3(:,1),'-.','LineWidth',2)
hold on
title('Effort','Interpreter','latex')
legend('ITAE','Bessel','Butterworth','Interpreter','latex')
grid on
grid minor
set(gca,'FontSize',12)
set(gca,'fontname','Times New Roman') 
xlabel('Time, s','Interpreter','latex')
ylabel('-Ku','Interpreter','latex')
ylim([-10 5])
xlim([0 2])