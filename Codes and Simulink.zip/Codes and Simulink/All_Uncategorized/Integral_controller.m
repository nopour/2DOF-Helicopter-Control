close all
clear all
clc
A=[      0         0    1.0000         0
         0         0         0    1.0000
         0         0   -9.2751         0
         0         0         0   -3.4955];
     
B=[      0         0
         0         0
    2.3667    0.0790
    0.2410    0.7913];
C=eye(4);


D = [1 1 0 0];
Ai = [A zeros(4,1);D zeros(1,1)];
Bi = [B;zeros(1,2)];
%bessel wn=4
poles =[ -11.5848-3.4689i
 -11.5848+3.4689i
  -8.4152-10.6297i
  -8.4152+10.6297i
  -10];

K = place(Ai,Bi,poles)
test = eig(Ai-Bi*K)