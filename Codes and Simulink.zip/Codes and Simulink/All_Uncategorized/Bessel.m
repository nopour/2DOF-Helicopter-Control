clc;clear all;close all
% Poles placing using Bessel method 
A=[      0         0    1.0000         0
         0         0         0    1.0000
         0         0   -9.2751         0
         0         0         0   -3.4955];
     
B=[      0         0
         0         0
    2.3667    0.0790
    0.2410    0.7913];
C=[  1     0     0     0
     0     1     0     0];

 D=[  0     0
     0     0];

% The frequency-scaled denominator of the Bessel transfer function
% may be rewritten for the n=4 case above as follows:

for i=2:2:8
w_n = 1


syms s
S_desired = s^4 + 10*s^3 + 45*s^2 + 105*s + 105;

num=105;
den=(s/w_n)^4 + 10*(s/w_n)^3 + 45*(s/w_n)^2 + 105*(s/w_n) + 105 ;

poles = double(vpasolve(den==0))
K_Bessel = place(A,B,poles)  % K obtained from Bessel criteria
A_new = A-B*K_Bessel ;
sys_new = ss(A_new,B,C,D)
% step(sys_new)
hold on

%% Response to Initial
x0=[2 0 3 0]
hold on
initial(sys_new,x0)

grid minor


end



