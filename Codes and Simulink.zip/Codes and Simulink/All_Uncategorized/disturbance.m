close all
clear all
clc


% Poles placing using Bessel method 
A=[      0         0    1.0000         0
         0         0         0    1.0000
         0         0   -9.2751         0
         0         0         0   -3.4955];
     
B=[      0         0
         0         0
    2.3667    0.0790
    0.2410    0.7913];
C=[  1     0     0     0
     0     1     0     0];

 D=[  0     0
     0     0];

 
Cd = eye(2,4);
F = [0;0;1;0];
E = [A F];

%BESSEL wn=4
K=[     68.5119  -25.1203    5.3421   -3.6881
   63.1652  188.4894    0.7783   19.4789];

Kd = inv(Cd*inv(A-B*K)*B)*Cd*inv(A-B*K)*E


sys_1 = ss(A,B,C,D);
hold on
A_bessel = A-B*K ;
sys_2 = ss(A_bessel,B,C,D);
hold on
A_dist = A-B*Kd ;
sys_3 = ss(A_dist,B,C,D);
%%
x0=[10 0 3 0]
initial(sys_1,x0)
hold on
initial(sys_2,x0)
hold on
initial(sys_3,x0)

