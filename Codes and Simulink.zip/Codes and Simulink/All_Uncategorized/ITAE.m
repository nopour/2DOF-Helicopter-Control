clc;clear;close all
% Poles placing using ITAE method 
% Integral of Time multiplied by Absolute Error

A=[      0         0    1.0000         0
         0         0         0    1.0000
         0         0   -9.2751         0
         0         0         0   -3.4955];

B=[      0         0
         0         0
    2.3667    0.0790
    0.2410    0.7913];

C=[  1     0     0     0
     0     1     0     0];

 D=[  0     0
     0     0];

n=4 ;   % n is order of the TF.denominator 
w_n = 8;
% % Desired Characteristic Eq in order 4
Delta_D = A^4 + 2.1*w_n*(A^3) + 3.4*(w_n^2)*(A^2)...
    + 2.7*(w_n^3)*A + (w_n^4)*eye(4);

syms s
poles_1=vpa(solve(s^4 + 2.1*w_n*(s^3)...
    + 3.4*(w_n^2)*(s^2)+ 2.7*(w_n^3)*(s) + (w_n^4)));
poles=double(poles_1);

K_ITAE = place(A,B,poles)  % K obtained from ITAE criteria
A_new = A-B*K_ITAE ;
sys_new = ss(A_new,B,C,D)
step(sys_new)

%% To plot INITIAL
% figure
% x0=[2 0 3 0]
% hold on
% initial(sys_new,x0)
% 
% grid minor

