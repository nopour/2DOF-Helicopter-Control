clc; close all
x1NL=out.NonLinear(:,1);
x2NL=out.NonLinear(:,2);
x3NL=out.NonLinear(:,3);
x4NL=out.NonLinear(:,4);

x1L=out.Linear(:,1);
x2L=out.Linear(:,2);
x3L=out.Linear(:,3);
x4L=out.Linear(:,4);

time=out.time;
subplot(2,2,1)
plot(time,x1NL,'linewidth',1.5,'color',"#EDB120")
hold on
plot(time,x1L,'--','linewidth',1.5,'color',"#0072BD")
grid minor
% legend('Linear','Nonlinear','interpreter','latex','Location','Best')
xlabel('Time','FontName','Yu Gothic','FontSize',12,'interpreter','latex')
ylabel('$\theta$','FontName','Yu Gothic','FontSize',12,'interpreter','latex')

subplot(2,2,2)
plot(time,x2NL,'linewidth',1.5,'color',"#EDB120")
hold on
plot(time,x2L,'--','linewidth',1.5,'color',"#0072BD")
grid minor
legend('NonLinear','linear','interpreter','latex','Location','Best')
xlabel('Time','FontName','Yu Gothic','FontSize',12,'interpreter','latex')
ylabel('$\psi$','FontName','Yu Gothic','FontSize',12,'interpreter','latex')

subplot(2,2,3)
plot(time,x3NL,'linewidth',1.5,'color',"#EDB120")
hold on
plot(time,x3L,'--','linewidth',1.5,'color',"#0072BD")
grid minor
% legend('Linear','Nonlinear','interpreter','latex','Location','Bestoutside')
xlabel('Time','FontName','Yu Gothic','FontSize',12,'interpreter','latex')
ylabel('$\dot\theta$','FontName','Yu Gothic','FontSize',12,'interpreter','latex')

subplot(2,2,4)
plot(time,x4NL,'linewidth',1.5,'color',"#EDB120")
hold on
plot(time,x4L,'--','linewidth',1.5,'color',"#0072BD")
grid minor
% legend('Linear','Nonlinear','interpreter','latex','Location','Bestoutside')
xlabel('Time','FontName','Yu Gothic','FontSize',12,'interpreter','latex')
ylabel('$\dot\psi$','FontName','Yu Gothic','FontSize',12,'interpreter','latex')
