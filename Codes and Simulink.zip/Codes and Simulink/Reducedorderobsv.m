clc;clear all;close all
% reduced order observer design
%% ُState Space
A=[      0         0    1.0000         0
         0         0         0    1.0000
         0         0   -9.2751         0
         0         0         0   -3.4955];

B=[      0         0
         0         0
    2.3667    0.0790
    0.2410    0.7913];

C=[  1     0     0     0
     0     1     0     0];

 D=[  0     0
     0     0];
%%
% poles=[-20-4i -20+4i -30-2i -30+2i]
% K=place(A,B,poles)
%% reduced observer
A_ss=A(1:2,1:2)
A_se=A(1:2,3:4)
A_es=A(3:4,1:2)
A_ee=A(3:4,3:4)
B_s=B(1:2,:)
B_e=B(3:4,:)
C_s=C(1:2,1:2)
C_e=C(1:2,3:4)
L=place(A_ee',(C_s*A_se)',([-25 -15]))'
F=A_ee-L*C_s*A_se
G=F*L+(A_es-L*C_s*A_ss)*inv(C_s)
H=B_e-L*C_s*B_s



