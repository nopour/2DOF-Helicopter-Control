clc;clear all;close all
% observer design
A=[      0         0    1.0000         0
         0         0         0    1.0000
         0         0   -9.2751         0
         0         0         0   -3.4955];

B=[      0         0
         0         0
    2.3667    0.0790
    0.2410    0.7913];

C=[  1     0     0     0
     0     1     0     0];

 D=[  0     0
     0     0];

poles=[-0.1 -0.2 -8 -2]
L = (place(A,B,poles))'

Aobs=[A-L*C]
Bobs=[B L]
Cobs=[  1     0     0     0;     0     1     0     0];
Dobs=zeros(2,4);

% sys_new = ss(Aobs,Bobs,Cobs,Dobs)
% step(sys_new)


