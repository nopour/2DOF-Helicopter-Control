clc;clear all;close all
% Poles placing using Chebyshev filter 

A=[      0         0    1.0000         0
         0         0         0    1.0000
         0         0   -9.2751         0
         0         0         0   -3.4955];

B=[      0         0
         0         0
    2.3667    0.0790
    0.2410    0.7913];

C=[  1     0     0     0
     0     1     0     0];
 
 D=[  0     0
     0     0];
 
% Chebyshev Polynomials of the First Kind
n=4 ;   % n is order of the TF.denominator 
for i=2:2:8
w_n = i

% Desired Characteristic Eq in order 4
syms s
T4 = 8*(s/w_n)^4 -8*(s/w_n)^2 + 1;
epsilon=0.1
poles_1=vpa(solve(1+epsilon^2*T4^2==0));
poles=double(poles_1);
poles= poles(poles<0)

K_Chebyshev = place(A,B,poles)  % K obtained from ITAE criteria
A_new = A-B*K_Chebyshev ;
sys_new = ss(A_new,B,C,D)
% step(sys_new)

% Response to Initial
x0=[2 0 3 0]
hold on
initial(sys_new,x0)
hold on
end
legend('\omega_n =2','\omega_n =4','\omega_n =6','\omega_n =8')
grid on
grid minor


